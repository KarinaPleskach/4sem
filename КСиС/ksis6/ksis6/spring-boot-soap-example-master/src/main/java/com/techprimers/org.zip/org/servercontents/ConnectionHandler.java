package org.servercontents;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ConnectionHandler implements  Runnable{

    private  Socket socket;
    private  SocketServer server ;
    private  PrintWriter  pr;


    ConnectionHandler(SocketServer server , Socket socket ) {
        this.server =server;
        this.socket =socket;
        try {
            OutputStream os = socket.getOutputStream();
            pr = new PrintWriter(os);

        } catch (IOException e) {
            System.out.println(e);
        }

    }

    @Override
    public void run() {

        try {
            InputStream is = socket.getInputStream();//get input from client
            Scanner sc = new Scanner(is);

                while (sc.hasNextLine()) {//while client send data keep reading and send to the screen
                    String msg = sc.nextLine();
                    System.out.println(msg);
                    server.broadcastMsg(msg,ConnectionHandler.this);
                }

            sc.close();// close when client stop
            socket.close();

        }catch (IOException e) {
            System.out.println(e);
        }
    }

     void sendMsg(String msg){

        pr.println(msg);
        pr.flush();
    }
}
