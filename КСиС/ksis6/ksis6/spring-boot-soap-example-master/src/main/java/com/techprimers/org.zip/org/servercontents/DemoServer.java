package org.servercontents;

import java.io.IOException;

public class DemoServer {


    public static void main(String[] args) throws IOException {

        new SocketServer();


    }
}
