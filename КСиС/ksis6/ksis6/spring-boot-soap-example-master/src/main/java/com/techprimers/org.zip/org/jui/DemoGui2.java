package org.jui;

import java.io.IOException;

public class DemoGui2 {


    public static void main(String[] args) throws IOException {
        new ClientGUI();

    }

}
