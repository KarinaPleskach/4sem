package org.jui;

import java.io.IOException;

public class DemoGui {

    public static void main(String[] args) throws IOException {
        new ClientGUI();

    }

}
