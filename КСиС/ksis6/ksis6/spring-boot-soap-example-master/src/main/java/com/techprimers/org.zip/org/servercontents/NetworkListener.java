package org.servercontents;

public interface NetworkListener {

    public void messageReceived (String msg);
}

